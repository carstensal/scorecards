

### Download

The following downloads are available

* The binning for each variable

* The original data with the final score and probabilities created in the dataset

* The scorecard specifications comprising of each characteristic, attribute and the score points for each attribute

* The underlying tables used to create the validation metrics

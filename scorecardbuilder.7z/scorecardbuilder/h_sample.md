

### Sample

Use the slider to choose what percentage of the records should be in the training sample. The remaining records will be in the test sample.


```
## Error in knitr::include_graphics("www/sample-choose.png"): Cannot find the file(s): "www/sample-choose.png"
```

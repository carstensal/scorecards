

### Explore

This tab allows you to do exploratory analysis on your data. You can either view a summary of all variables or see the details for a single variable.


```
## Error in knitr::include_graphics("www/explore-all.png"): Cannot find the file(s): "www/explore-all.png"
```


```
## Error in knitr::include_graphics("www/explore-single.png"): Cannot find the file(s): "www/explore-single.png"
```

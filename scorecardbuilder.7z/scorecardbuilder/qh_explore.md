

## Help
##### (Click ? for hints)

* Choose whether to see a summary report of all variables or the report for a single variable.

* Only numeric and categorical variables are shown when viewing a single variable.

* If there is more than one mode, a maximum of five modes are shown.

* If a categorical variable has more than 30 distinct values, only the top 29 values with the highest frequencies are displayed and the remaining are combined into OTHERS.

* Missing values of a categorical variable are converted to the value MISSING.

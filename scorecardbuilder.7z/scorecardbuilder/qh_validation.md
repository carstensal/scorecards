

## Help
##### (Click ? for hints)

* This tab displays the validation metrics for the scorecard. Discrimination,
accuracy and stability metrics are calculated.

* The underlying tables based on which the metrics are calculated are available
from the Downloads tab.

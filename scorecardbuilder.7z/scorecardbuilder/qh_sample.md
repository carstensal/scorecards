

## Help
##### (Click ? for hints)

* Sampling can only be done once the good/bad flag is specified in the
Data tab.

* The good/bad flag along with the stratification variable(s) chosen in the
Data tab will be used to stratify the sample.
C1

* The charts display the distribution of the good/bad flag and stratification
variables to ensure they are roughly equal in both the samples.
